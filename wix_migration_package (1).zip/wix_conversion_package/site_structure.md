# Site Structure Analysis for Wix Velo Migration

## Overview
The Replit project is a React application with TypeScript for a transportation service called "AMZ Express". The site uses:
- React with TypeScript
- Wouter for routing
- TailwindCSS for styling
- Shadcn UI components
- Backend server with Express

## Site Pages
1. **Home** - Landing page with hero section, services showcase, and chatbot
2. **Services** - Details about transportation services offered
3. **Why Choose Us** - Company advantages and unique selling points
4. **Testimonials** - Customer reviews and feedback
5. **Events** - Special events like Brown Sugar Festival
6. **Contact** - Contact form and information
7. **Booking** - Service booking form
8. **Not Found** - 404 error page

## Components Structure
1. **Layout Component** - Contains header and footer that appear on all pages
2. **UI Components** - Various UI elements like buttons, forms, cards, etc.
3. **Custom Components**:
   - Chatbot
   - Booking Form
   - Onboarding Wizard
   - Page Transition
   - Admin Authentication
   - Protected Route

## Backend Functionality
The server directory contains:
- API routes
- Database connection
- OpenAI integration
- File storage

## Modular Sections for Wix Migration

### 1. Master Page Components (Site Level)
- Header with navigation
- Footer with contact info and links

### 2. Page-Specific Components
- Home page hero section
- Services showcase cards
- Testimonials display
- Contact form
- Booking form
- Events display

### 3. Reusable UI Components
- Buttons
- Cards
- Forms
- Navigation elements
- Modals/Dialogs

### 4. Dynamic Functionality
- Chatbot integration
- Onboarding wizard
- Page transitions
- Authentication

### 5. Backend Services to Migrate
- Form submissions
- OpenAI integration
- Data storage and retrieval

## Migration Approach
For Wix Velo migration, we'll need to:
1. Create Wix pages for each route in the React app
2. Build the layout structure using Wix's master page concept
3. Convert React components to Wix custom elements
4. Implement styling using Wix's custom CSS capabilities
5. Replace React state management with Wix Velo's state management
6. Convert backend functionality to Wix Velo backend
7. Replace direct DOM manipulation with Wix's $w selector syntax
