// =============================================
// ONBOARDING WIZARD COMPONENT CODE
// =============================================
// This code should be placed in a Custom Element code section in Wix Editor

import {local} from 'wix-storage';

$w.onReady(function () {
    // Check if onboarding has been completed
    const hasCompletedOnboarding = local.getItem('onboardingCompleted');
    
    // If not completed, show the onboarding wizard
    if (!hasCompletedOnboarding) {
        $w('#onboardingContainer').expand();
        
        // Set up step navigation
        setupStepNavigation();
        
        // Set up completion button
        $w('#completeButton').onClick(() => {
            completeOnboarding();
        });
    } else {
        // Hide the onboarding wizard
        $w('#onboardingContainer').collapse();
    }
});

// Function to set up step navigation
function setupStepNavigation() {
    // Initialize current step
    let currentStep = 1;
    const totalSteps = 3; // Adjust based on your actual number of steps
    
    // Show first step, hide others
    showStep(currentStep);
    
    // Set up next button
    $w('#nextButton').onClick(() => {
        if (currentStep < totalSteps) {
            currentStep++;
            showStep(currentStep);
        }
    });
    
    // Set up back button
    $w('#backButton').onClick(() => {
        if (currentStep > 1) {
            currentStep--;
            showStep(currentStep);
        }
    });
}

// Function to show a specific step
function showStep(stepNumber) {
    // Hide all steps
    for (let i = 1; i <= 3; i++) {
        $w(`#step${i}Container`).hide();
    }
    
    // Show current step
    $w(`#step${stepNumber}Container`).show();
    
    // Update step indicator
    $w('#stepIndicator').text = `Step ${stepNumber} of 3`;
    
    // Update button visibility
    if (stepNumber === 1) {
        $w('#backButton').hide();
    } else {
        $w('#backButton').show();
    }
    
    if (stepNumber === 3) {
        $w('#nextButton').hide();
        $w('#completeButton').show();
    } else {
        $w('#nextButton').show();
        $w('#completeButton').hide();
    }
}

// Function to complete onboarding
function completeOnboarding() {
    // Mark onboarding as completed
    local.setItem('onboardingCompleted', 'true');
    
    // Hide the onboarding wizard with animation
    $w('#onboardingContainer').hide('fade', { duration: 500 });
    
    // After animation completes, collapse the container
    setTimeout(() => {
        $w('#onboardingContainer').collapse();
    }, 500);
}
