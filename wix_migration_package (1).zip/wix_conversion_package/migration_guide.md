# AMZ Express Website Migration Guide
## From Replit to Wix Velo

This comprehensive guide will walk you through migrating your custom-coded Replit website to Wix Velo. The migration has been carefully planned to preserve all functionality while leveraging Wix's powerful platform capabilities.

## Table of Contents

1. [Project Overview](#project-overview)
2. [Site Structure Analysis](#site-structure-analysis)
3. [Migration Strategy](#migration-strategy)
4. [Implementation Instructions](#implementation-instructions)
5. [Component Conversion Reference](#component-conversion-reference)
6. [Styling Guide](#styling-guide)
7. [Backend Integration](#backend-integration)
8. [External Libraries Alternatives](#external-libraries-alternatives)
9. [Testing Checklist](#testing-checklist)
10. [Post-Migration Considerations](#post-migration-considerations)

## Project Overview

The original website is a React application with TypeScript for AMZ Express Transportation, featuring:

- Multiple pages (Home, Services, Why Choose Us, Testimonials, Events, Contact, Booking)
- Interactive components (Chatbot, Booking Form, Onboarding Wizard)
- Consistent layout with header and footer
- TailwindCSS for styling
- Backend functionality for form submissions and chat

This migration guide converts all these elements to Wix Velo-compatible code while maintaining the same visual appearance and functionality.

## Site Structure Analysis

The site has been analyzed and broken down into the following components:

### Master Page Components
- Header with navigation
- Footer with contact info and links

### Page-Specific Components
- Home page with hero section, services showcase, and chatbot
- Services page with service cards
- Booking page with booking form
- Other content pages (Why Choose Us, Testimonials, Events, Contact)

### Interactive Components
- Chatbot for customer inquiries
- Booking form for service reservations
- Onboarding wizard for new users
- Page transitions for smooth navigation

### Backend Functionality
- API endpoints for form submissions
- Database integration for storing bookings
- Chat message handling

## Migration Strategy

The migration follows these key principles:

1. **Component-Based Approach**: Each React component is converted to a Wix custom element or page
2. **$w Selector Syntax**: All DOM manipulation is replaced with Wix's $w selector syntax
3. **Wix APIs**: Utilizing Wix's built-in APIs (wixData, wixLocation, wixWindow, etc.)
4. **Custom CSS**: TailwindCSS utilities converted to standard CSS for Wix
5. **Database Collections**: React backend replaced with Wix collections and HTTP functions

## Implementation Instructions

Please refer to the detailed [Implementation Instructions](implementation_instructions.md) document for step-by-step guidance on implementing this migration in Wix Velo.

## Component Conversion Reference

| React Component | Wix Velo Implementation | File Reference |
|-----------------|-------------------------|----------------|
| Layout | Master Page | master_page.js, master_page_html.html |
| Home | Home Page | home_page.js, home_page_html.html |
| Services | Services Page | services_page.js, services_page_html.html |
| Booking Form | Custom Element | booking_form_component.js, booking_form_html.html |
| Chatbot | Custom Element | chatbot_component.js, chatbot_component_html.html |
| Page Transition | Custom Element | page_transition.js |
| Onboarding Wizard | Custom Element | onboarding_wizard.js |

## Styling Guide

All TailwindCSS styles have been converted to standard CSS for Wix. The styling is organized as follows:

- **Master Page CSS**: Header and footer styling (master_page_css.css)
- **Home Page CSS**: Hero section, services showcase, and chat section styling (home_page_css.css)
- **Services Page CSS**: Service cards styling (services_page_css.css)
- **Booking Form CSS**: Form styling with validation states (booking_form_css.css)
- **Chatbot CSS**: Chat interface styling (chatbot_css.css)

To implement these styles, add them to your Wix site's custom CSS file as described in the implementation instructions.

## Backend Integration

The backend functionality has been converted to use Wix's data capabilities:

1. **Database Collections**: Create a "Bookings" collection in Wix Content Manager
2. **HTTP Functions**: Implement API endpoints using Wix HTTP Functions
3. **Data Operations**: Use wixData API for database operations

See backend_integration.js for detailed implementation code.

## External Libraries Alternatives

The original React application used several external libraries that have been replaced with Wix Velo alternatives:

- **react-hook-form + zod**: Replaced with custom validation using $w API
- **@tanstack/react-query**: Replaced with wixFetch and wixData APIs
- **wouter**: Replaced with wixLocation API
- **lucide-react**: Replaced with SVG elements or Wix's built-in icons
- **shadcn/ui**: Replaced with Wix's built-in UI elements or custom styling

See external_libraries_alternatives.js for detailed implementation examples.

## Testing Checklist

After implementing the migration, test the following functionality:

- [ ] Navigation between all pages
- [ ] Responsive design on different screen sizes
- [ ] Booking form submission and validation
- [ ] Chatbot interaction
- [ ] Onboarding wizard for new users
- [ ] Page transitions
- [ ] All images and assets loading correctly
- [ ] Backend functionality (form submissions, data storage)

## Post-Migration Considerations

After successfully migrating to Wix Velo, consider these next steps:

1. **SEO Optimization**: Utilize Wix's SEO tools to improve search engine visibility
2. **Analytics Integration**: Set up analytics to track user behavior
3. **Performance Optimization**: Optimize image sizes and loading performance
4. **Content Updates**: Regularly update content to keep the site fresh
5. **Feature Expansion**: Consider adding new features using Wix's app market

---

This migration guide provides a comprehensive roadmap for transitioning your Replit website to Wix Velo. By following the detailed instructions and leveraging the converted code files, you'll be able to recreate your website's functionality and design within the Wix platform.
