// =============================================
// HOME PAGE CODE
// =============================================
// This code should be placed in the Home Page code section in Wix Editor

import wixLocation from 'wix-location';
import wixWindow from 'wix-window';
import {local} from 'wix-storage';

$w.onReady(function () {
    // Set welcome message
    setWelcomeMessage();
    
    // Check if onboarding should be shown
    checkOnboarding();
    
    // Set up button click handlers
    setupButtons();
});

// Function to set welcome message
function setWelcomeMessage() {
    // In Wix, we'll use a simpler welcome message approach
    const hour = new Date().getHours();
    let welcomeMessage = "Welcome to AMZ Express Transportation";
    
    if (hour < 12) {
        welcomeMessage = "Good Morning! Welcome to AMZ Express Transportation";
    } else if (hour < 18) {
        welcomeMessage = "Good Afternoon! Welcome to AMZ Express Transportation";
    } else {
        welcomeMessage = "Good Evening! Welcome to AMZ Express Transportation";
    }
    
    $w('#heroHeading').text = welcomeMessage;
}

// Function to check if onboarding should be shown
function checkOnboarding() {
    // Check if user has completed onboarding
    const hasCompletedOnboarding = local.getItem('onboardingCompleted');
    
    if (!hasCompletedOnboarding) {
        // Show onboarding wizard
        $w('#onboardingSection').expand();
        
        // Set up onboarding completion button
        $w('#completeOnboardingButton').onClick(() => {
            local.setItem('onboardingCompleted', 'true');
            $w('#onboardingSection').collapse();
        });
    } else {
        // Hide onboarding wizard
        $w('#onboardingSection').collapse();
    }
}

// Function to set up button click handlers
function setupButtons() {
    // Book Now button in hero section
    $w('#heroBookNowButton').onClick(() => {
        wixLocation.to('/booking');
    });
    
    // Learn More buttons in service cards
    $w('#schoolLearnMoreButton').onClick(() => {
        wixLocation.to('/services#school');
    });
    
    $w('#tourLearnMoreButton').onClick(() => {
        wixLocation.to('/services#tours');
    });
}
