# Implementation Instructions for Migrating to Wix Velo

This document provides step-by-step instructions for implementing your Replit website in Wix Velo. Follow these instructions in order to ensure a successful migration.

## 1. Initial Setup in Wix

1. **Create a new Wix site**:
   - Go to [Wix.com](https://www.wix.com/) and sign up or log in
   - Choose "Create a New Site" and select a blank template
   - When asked about your experience, select "I've created websites before"

2. **Enable Velo**:
   - Click on "Dev Mode" in the top bar of the Wix Editor
   - Click "Turn on Dev Mode"
   - This will enable Wix Velo development features

3. **Set up site structure**:
   - Create the following pages in your Wix site:
     - Home
     - Services
     - Why Choose Us
     - Testimonials
     - Events
     - Contact
     - Booking
     - Not Found (404)

## 2. Master Page Implementation

1. **Create Master Page elements**:
   - In the Wix Editor, go to "Site" > "Master Page"
   - Follow the HTML structure in `master_page_html.html` to add all required elements
   - Make sure to set the correct IDs for all elements as specified

2. **Add Master Page code**:
   - In the Wix Editor, go to "Dev Mode" > "Site Code" > "masterPage.js"
   - Copy and paste the code from `master_page.js`
   - Save the changes

3. **Add Master Page CSS**:
   - In the Wix Editor, go to "Dev Mode" > "Site Code" > "Public" > "custom.css"
   - If the file doesn't exist, create it
   - Copy and paste the CSS from `master_page_css.css`
   - Save the changes

## 3. Page-Specific Implementations

### 3.1 Home Page

1. **Create Home Page elements**:
   - Navigate to the Home page in the Wix Editor
   - Follow the HTML structure in `home_page_html.html` to add all required elements
   - Make sure to set the correct IDs for all elements as specified
   - Upload the required images (school-bus.webp and tour-bus.webp) to the Wix Media Manager

2. **Add Home Page code**:
   - In the Wix Editor, go to "Dev Mode" > "Page Code" (while on the Home page)
   - Copy and paste the code from `home_page.js`
   - Save the changes

3. **Add Home Page CSS**:
   - Add the CSS from `home_page_css.css` to your "custom.css" file
   - Save the changes

### 3.2 Services Page

1. **Create Services Page elements**:
   - Navigate to the Services page in the Wix Editor
   - Follow the HTML structure in `services_page_html.html` to add all required elements
   - Make sure to set the correct IDs for all elements as specified
   - Upload all service images to the Wix Media Manager

2. **Add Services Page code**:
   - In the Wix Editor, go to "Dev Mode" > "Page Code" (while on the Services page)
   - Copy and paste the code from `services_page.js`
   - Save the changes

3. **Add Services Page CSS**:
   - Add the CSS from `services_page_css.css` to your "custom.css" file
   - Save the changes

### 3.3 Booking Page

1. **Create Booking Form component**:
   - In the Wix Editor, go to "Dev Mode" > "Public & Backend" > "Components"
   - Click "New Component" and name it "BookingForm"
   - In the component editor, follow the HTML structure in `booking_form_html.html`
   - Make sure to set the correct IDs for all elements as specified

2. **Add Booking Form code**:
   - In the component editor, add the code from `booking_form_component.js`
   - Save the component

3. **Add Booking Form CSS**:
   - Add the CSS from `booking_form_css.css` to your "custom.css" file
   - Save the changes

4. **Add Booking Form to Booking Page**:
   - Navigate to the Booking page in the Wix Editor
   - Add a container element to the page
   - From the "Add Elements" panel, find your custom "BookingForm" component and add it to the container

## 4. Custom Components Implementation

### 4.1 Chatbot Component

1. **Create Chatbot component**:
   - In the Wix Editor, go to "Dev Mode" > "Public & Backend" > "Components"
   - Click "New Component" and name it "Chatbot"
   - In the component editor, follow the HTML structure in `chatbot_component_html.html`
   - Make sure to set the correct IDs for all elements as specified

2. **Add Chatbot code**:
   - In the component editor, add the code from `chatbot_component.js`
   - Save the component

3. **Add Chatbot CSS**:
   - Add the CSS from `chatbot_css.css` to your "custom.css" file
   - Save the changes

4. **Add Chatbot to Home Page**:
   - Navigate to the Home page in the Wix Editor
   - Find the chat section you created earlier
   - From the "Add Elements" panel, find your custom "Chatbot" component and add it to the chat section

### 4.2 Page Transition Component

1. **Create Page Transition component**:
   - In the Wix Editor, go to "Dev Mode" > "Public & Backend" > "Components"
   - Click "New Component" and name it "PageTransition"
   - In the component editor, add a container element with ID "#pageContent"

2. **Add Page Transition code**:
   - In the component editor, add the code from `page_transition.js`
   - Save the component

3. **Add Page Transition to Master Page**:
   - Navigate to the Master Page in the Wix Editor
   - From the "Add Elements" panel, find your custom "PageTransition" component
   - Add it to the main content area of your Master Page

### 4.3 Onboarding Wizard Component

1. **Create Onboarding Wizard component**:
   - In the Wix Editor, go to "Dev Mode" > "Public & Backend" > "Components"
   - Click "New Component" and name it "OnboardingWizard"
   - In the component editor, create a container with ID "#onboardingContainer"
   - Add step containers with IDs "#step1Container", "#step2Container", "#step3Container"
   - Add navigation buttons with IDs "#backButton", "#nextButton", "#completeButton"
   - Add a step indicator text element with ID "#stepIndicator"

2. **Add Onboarding Wizard code**:
   - In the component editor, add the code from `onboarding_wizard.js`
   - Save the component

3. **Add Onboarding Wizard to Home Page**:
   - Navigate to the Home page in the Wix Editor
   - From the "Add Elements" panel, find your custom "OnboardingWizard" component
   - Add it to the onboarding section you created earlier

## 5. Backend Implementation

1. **Create Database Collections**:
   - In the Wix Dashboard, go to "Content Manager" > "Add Collection"
   - Create a "Bookings" collection with the following fields:
     - service (Text): Type of service booked
     - date (Date): Date of booking
     - time (Text): Time of booking
     - name (Text): Customer's full name
     - email (Text): Customer's email
     - phone (Text): Customer's phone number
     - message (Text): Additional information
     - status (Text): Booking status (default: "pending")
     - createdDate (Date): When the booking was created

2. **Set up Backend Code**:
   - In the Wix Editor, go to "Dev Mode" > "Public & Backend" > "Backend"
   - Create a new file called "http-functions.js"
   - Copy and paste the relevant code from `backend_integration.js`
   - Save the changes

## 6. External Libraries Considerations

Review the `external_libraries_alternatives.js` file for guidance on how to handle the external libraries used in the original React application. The file provides Wix Velo alternatives for:

1. Form validation (react-hook-form + zod)
2. Data fetching (react-query)
3. Routing (wouter)
4. Icons (lucide-react)
5. UI Components (shadcn/ui)

## 7. Testing and Troubleshooting

1. **Preview your site**:
   - Click "Preview" in the Wix Editor to test your site
   - Test all pages and functionality

2. **Common issues and solutions**:
   - If elements aren't responding to events, check that the element IDs match exactly
   - If styles aren't applying, make sure the custom CSS is properly added
   - If backend functions aren't working, check the Wix Velo logs for errors

3. **Debugging**:
   - Use `console.log()` statements in your code to debug issues
   - Check the browser console for errors while in Preview mode

## 8. Publishing Your Site

1. **Final review**:
   - Test all functionality one more time
   - Check all pages on different device sizes

2. **Publish**:
   - Click "Publish" in the Wix Editor
   - Follow the prompts to publish your site

3. **Connect domain**:
   - In the Wix Dashboard, go to "Domains"
   - Follow the instructions to connect your custom domain

## 9. Post-Launch Considerations

1. **SEO optimization**:
   - In the Wix Dashboard, go to "SEO Tools"
   - Set up SEO for each page

2. **Analytics**:
   - In the Wix Dashboard, go to "Analytics"
   - Set up tracking to monitor site performance

3. **Maintenance**:
   - Regularly check for Wix updates
   - Keep your content fresh and up-to-date
