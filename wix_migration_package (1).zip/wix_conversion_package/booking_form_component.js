// =============================================
// BOOKING FORM COMPONENT CODE
// =============================================
// This code should be placed in a Custom Element code section in Wix Editor

import wixData from 'wix-data';
import {local} from 'wix-storage';

$w.onReady(function () {
    // Initialize form
    setupForm();
    
    // Set up form submission
    $w('#submitButton').onClick(() => {
        if (validateForm()) {
            submitForm();
        }
    });
});

// Function to set up the form
function setupForm() {
    // Set up service type dropdown
    $w('#serviceDropdown').onChange(() => {
        // Clear validation error if exists
        $w('#serviceError').collapse();
    });
    
    // Set up date and time inputs
    $w('#dateInput').onChange(() => {
        $w('#dateError').collapse();
    });
    
    $w('#timeInput').onChange(() => {
        $w('#timeError').collapse();
    });
    
    // Set up other form fields
    $w('#nameInput').onChange(() => {
        $w('#nameError').collapse();
    });
    
    $w('#emailInput').onChange(() => {
        $w('#emailError').collapse();
    });
    
    $w('#phoneInput').onChange(() => {
        $w('#phoneError').collapse();
    });
}

// Function to validate the form
function validateForm() {
    let isValid = true;
    
    // Validate service type
    if (!$w('#serviceDropdown').value) {
        $w('#serviceError').expand();
        isValid = false;
    }
    
    // Validate date
    if (!$w('#dateInput').value) {
        $w('#dateError').expand();
        isValid = false;
    }
    
    // Validate time
    if (!$w('#timeInput').value) {
        $w('#timeError').expand();
        isValid = false;
    }
    
    // Validate name
    if (!$w('#nameInput').value) {
        $w('#nameError').expand();
        isValid = false;
    }
    
    // Validate email
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!$w('#emailInput').value || !emailRegex.test($w('#emailInput').value)) {
        $w('#emailError').expand();
        isValid = false;
    }
    
    // Validate phone
    if (!$w('#phoneInput').value) {
        $w('#phoneError').expand();
        isValid = false;
    }
    
    return isValid;
}

// Function to submit the form
function submitForm() {
    // Disable submit button and show loading state
    $w('#submitButton').disable();
    $w('#submitButton').label = "Submitting...";
    
    // Prepare data for submission
    const bookingData = {
        service: $w('#serviceDropdown').value,
        date: $w('#dateInput').value,
        time: $w('#timeInput').value,
        name: $w('#nameInput').value,
        email: $w('#emailInput').value,
        phone: $w('#phoneInput').value,
        message: $w('#messageInput').value || ""
    };
    
    // Submit to Wix Data collection
    wixData.insert('Bookings', bookingData)
        .then((results) => {
            // Show success message
            $w('#successMessage').expand();
            
            // Reset form
            resetForm();
            
            // Hide success message after 5 seconds
            setTimeout(() => {
                $w('#successMessage').collapse();
            }, 5000);
        })
        .catch((error) => {
            // Show error message
            $w('#errorMessage').expand();
            
            // Hide error message after 5 seconds
            setTimeout(() => {
                $w('#errorMessage').collapse();
            }, 5000);
            
            console.error("Error submitting booking:", error);
        })
        .finally(() => {
            // Re-enable submit button
            $w('#submitButton').enable();
            $w('#submitButton').label = "Book Now";
        });
}

// Function to reset the form
function resetForm() {
    $w('#serviceDropdown').value = "";
    $w('#dateInput').value = "";
    $w('#timeInput').value = "";
    $w('#nameInput').value = "";
    $w('#emailInput').value = "";
    $w('#phoneInput').value = "";
    $w('#messageInput').value = "";
}
