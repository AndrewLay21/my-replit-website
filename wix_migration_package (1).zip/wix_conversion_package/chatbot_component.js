// =============================================
// CHATBOT COMPONENT CODE
// =============================================
// This code should be placed in a Custom Element code section in Wix Editor

import wixFetch from 'wix-fetch';
import {local} from 'wix-storage';

// Initialize component with default state
$w.onReady(function () {
    // Initialize messages array in local storage if not exists
    if (!local.getItem('chatMessages')) {
        local.setItem('chatMessages', JSON.stringify([]));
    }
    
    // Display existing messages
    displayMessages();
    
    // Set up send button click handler
    $w('#sendButton').onClick(() => {
        handleSendMessage();
    });
    
    // Set up input keypress handler for Enter key
    $w('#messageInput').onKeyPress((event) => {
        if (event.key === 'Enter') {
            handleSendMessage();
        }
    });
});

// Function to handle sending a message
function handleSendMessage() {
    const messageText = $w('#messageInput').value;
    
    // Don't send empty messages
    if (!messageText.trim()) {
        return;
    }
    
    // Add user message to chat
    addMessage('user', messageText);
    
    // Clear input field
    $w('#messageInput').value = '';
    
    // Show loading indicator
    $w('#loadingIndicator').expand();
    
    // Disable input and button while loading
    $w('#messageInput').disable();
    $w('#sendButton').disable();
    
    // Send message to backend
    sendMessageToBackend(messageText)
        .then(response => {
            // Add assistant response to chat
            addMessage('assistant', response.message);
        })
        .catch(error => {
            console.error('Chat error:', error);
            // Show error message
            $w('#errorMessage').text = 'Failed to get response. Please try again.';
            $w('#errorMessage').expand();
            
            // Hide error after 3 seconds
            setTimeout(() => {
                $w('#errorMessage').collapse();
            }, 3000);
        })
        .finally(() => {
            // Hide loading indicator
            $w('#loadingIndicator').collapse();
            
            // Re-enable input and button
            $w('#messageInput').enable();
            $w('#sendButton').enable();
        });
}

// Function to add a message to the chat
function addMessage(role, content) {
    // Get existing messages
    const messages = JSON.parse(local.getItem('chatMessages') || '[]');
    
    // Add new message
    messages.push({ role, content });
    
    // Save updated messages
    local.setItem('chatMessages', JSON.stringify(messages));
    
    // Update display
    displayMessages();
    
    // Scroll to bottom
    $w('#chatScrollBox').scrollTo(0, $w('#chatScrollBox').scrollHeight);
}

// Function to display messages in the chat
function displayMessages() {
    // Get messages from storage
    const messages = JSON.parse(local.getItem('chatMessages') || '[]');
    
    // Clear existing messages
    $w('#messagesContainer').html = '';
    
    // If no messages, show welcome message
    if (messages.length === 0) {
        $w('#messagesContainer').html = `
            <div class="text-center text-muted-foreground py-8">
                👋 Hi! How can I help you today?
            </div>
        `;
        return;
    }
    
    // Build HTML for messages
    let messagesHtml = '';
    
    messages.forEach(msg => {
        const alignment = msg.role === 'user' ? 'right' : 'left';
        const bgColor = msg.role === 'user' ? '#3182CE' : '#F7FAFC';
        const textColor = msg.role === 'user' ? 'white' : 'black';
        
        messagesHtml += `
            <div style="display: flex; justify-content: ${alignment === 'right' ? 'flex-end' : 'flex-start'}; margin-bottom: 10px;">
                <div style="background-color: ${bgColor}; color: ${textColor}; border-radius: 8px; padding: 8px 16px; max-width: 80%;">
                    ${msg.content}
                </div>
            </div>
        `;
    });
    
    // Set messages HTML
    $w('#messagesContainer').html = messagesHtml;
}

// Function to send message to backend
function sendMessageToBackend(message) {
    // In Wix, we'll use the Wix Fetch API to send requests
    return wixFetch.fetch('/api/chat', {
        method: 'post',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ message })
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Failed to get response');
        }
        return response.json();
    });
}
