// =============================================
// BACKEND INTEGRATION - DATABASE SETUP
// =============================================
// This code should be placed in the Backend section of Wix Velo

import wixData from 'wix-data';

// Create Bookings collection schema
export function createBookingsCollection() {
    // Note: This is a conceptual example. In Wix, you would typically create 
    // collections through the Wix Dashboard interface rather than code.
    
    // The Bookings collection should have the following fields:
    // - service (Text): Type of service booked
    // - date (Date): Date of booking
    // - time (Text): Time of booking
    // - name (Text): Customer's full name
    // - email (Text): Customer's email
    // - phone (Text): Customer's phone number
    // - message (Text): Additional information
    // - status (Text): Booking status (default: "pending")
    // - createdDate (Date): When the booking was created
}

// =============================================
// BACKEND INTEGRATION - API ENDPOINTS
// =============================================
// This code should be placed in the Backend/http-functions.js file in Wix Velo

import { ok, badRequest } from 'wix-http-functions';
import wixData from 'wix-data';
import { fetch } from 'wix-fetch';

// Handle chat messages (replacing the /api/chat endpoint)
export function post_chat(request) {
    // Parse the request body
    return request.body.json()
        .then((body) => {
            // Extract the message from the request
            const userMessage = body.message;
            
            // Here you would typically call an external API like OpenAI
            // For this example, we'll just return a simple response
            
            // In a real implementation, you would use Wix Secrets to store API keys
            // const apiKey = await wixSecretsBackend.getSecret("OPENAI_API_KEY");
            
            // Simulate API call to OpenAI or similar service
            return {
                message: `Thank you for your message: "${userMessage}". A representative will get back to you shortly.`
            };
        })
        .then((responseData) => {
            // Return a successful response
            return ok({
                headers: {
                    'Content-Type': 'application/json'
                },
                body: responseData
            });
        })
        .catch((error) => {
            // Return an error response
            return badRequest({
                headers: {
                    'Content-Type': 'application/json'
                },
                body: {
                    error: error.message
                }
            });
        });
}

// Handle booking submissions (replacing the /api/bookings endpoint)
export function post_bookings(request) {
    return request.body.json()
        .then((body) => {
            // Create a new booking record
            const bookingData = {
                service: body.service,
                date: new Date(body.date),
                time: body.time,
                name: body.name,
                email: body.email,
                phone: body.phone,
                message: body.message || "",
                status: "pending",
                createdDate: new Date()
            };
            
            // Insert the booking into the database
            return wixData.insert("Bookings", bookingData);
        })
        .then((results) => {
            // Return a successful response
            return ok({
                headers: {
                    'Content-Type': 'application/json'
                },
                body: {
                    id: results._id,
                    message: "Booking submitted successfully"
                }
            });
        })
        .catch((error) => {
            // Return an error response
            return badRequest({
                headers: {
                    'Content-Type': 'application/json'
                },
                body: {
                    error: error.message
                }
            });
        });
}
