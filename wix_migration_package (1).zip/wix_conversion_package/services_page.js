// =============================================
// SERVICES PAGE CODE
// =============================================
// This code should be placed in the Services Page code section in Wix Editor

import wixLocation from 'wix-location';

$w.onReady(function () {
    // Set up booking button click handlers for each service
    setupBookingButtons();
    
    // Handle image error fallbacks
    handleImageErrors();
});

// Function to set up booking button click handlers
function setupBookingButtons() {
    // School Bus booking button
    $w('#schoolBusBookButton').onClick(() => {
        wixLocation.to('/booking');
        // You can also pass the service type as a query parameter
        // wixLocation.to('/booking?service=school-bus');
    });
    
    // Tour Bus booking button
    $w('#tourBusBookButton').onClick(() => {
        wixLocation.to('/booking');
        // wixLocation.to('/booking?service=tour-bus');
    });
    
    // Passenger Van booking button
    $w('#passengerVanBookButton').onClick(() => {
        wixLocation.to('/booking');
        // wixLocation.to('/booking?service=passenger-van');
    });
    
    // Limousine booking button
    $w('#limoBookButton').onClick(() => {
        wixLocation.to('/booking');
        // wixLocation.to('/booking?service=limousine');
    });
    
    // Party Bus booking button
    $w('#partyBusBookButton').onClick(() => {
        wixLocation.to('/booking');
        // wixLocation.to('/booking?service=party-bus');
    });
    
    // Corporate Travel booking button
    $w('#corporateBookButton').onClick(() => {
        wixLocation.to('/booking');
        // wixLocation.to('/booking?service=corporate-travel');
    });
}

// Function to handle image errors
function handleImageErrors() {
    // In Wix, we'll use a different approach for image error handling
    // We'll set default fallback images in the Wix Editor properties panel
    // This is just a placeholder function for any additional error handling
}
