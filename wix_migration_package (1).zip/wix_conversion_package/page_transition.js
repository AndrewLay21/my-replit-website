// =============================================
// PAGE TRANSITION COMPONENT CODE
// =============================================
// This code should be placed in a Custom Element code section in Wix Editor

import wixWindow from 'wix-window';
import wixLocation from 'wix-location';
import {local} from 'wix-storage';

$w.onReady(function () {
    // Set up page transition effects
    setupPageTransition();
    
    // Listen for page navigation events
    listenForNavigation();
});

// Function to set up page transition effects
function setupPageTransition() {
    // Get current page path from URL
    const currentPath = wixLocation.path[0] || 'home';
    
    // Store current page in local storage for transition reference
    local.setItem('previousPage', currentPath);
    
    // Show page with fade-in animation
    $w('#pageContent').hide();
    setTimeout(() => {
        $w('#pageContent').show('fade', { duration: 500 });
    }, 100);
}

// Function to listen for navigation events
function listenForNavigation() {
    // This is a simplified version since Wix handles most navigation internally
    // We'll use this to prepare for transitions when links are clicked
    
    // Get all navigation links
    const navLinks = [
        '#homeLink', '#servicesLink', '#whyChooseUsLink', 
        '#testimonialsLink', '#eventsLink', '#contactLink',
        '#bookNowButton'
    ];
    
    // Add click handlers to prepare for transition
    navLinks.forEach(linkId => {
        if ($w(linkId).length > 0) {
            $w(linkId).onClick(() => {
                // Fade out content before navigation
                $w('#pageContent').hide('fade', { duration: 300 });
            });
        }
    });
}
