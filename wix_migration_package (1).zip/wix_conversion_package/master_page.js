// =============================================
// MASTER PAGE CODE - HEADER AND FOOTER
// =============================================
// This code should be placed in the Master Page code section in Wix Editor
// It handles the header and footer that will appear on all pages

import wixLocation from 'wix-location';

$w.onReady(function () {
    // Set up navigation highlighting based on current page
    highlightCurrentPage();
    
    // Set up navigation click handlers
    setupNavigationLinks();
    
    // Set up Book Now button click handler
    $w('#bookNowButton').onClick(() => {
        wixLocation.to('/booking');
    });
});

// Function to highlight the current page in navigation
function highlightCurrentPage() {
    // Get current page path
    const currentPath = wixLocation.path[0] || 'home';
    
    // Reset all navigation items to default style
    const navItems = [
        '#homeLink', '#servicesLink', '#whyChooseUsLink', 
        '#testimonialsLink', '#eventsLink', '#contactLink'
    ];
    
    navItems.forEach(item => {
        $w(item).style.color = '#718096'; // text-gray-600 equivalent
    });
    
    // Highlight current page
    switch (currentPath) {
        case 'home':
            $w('#homeLink').style.color = '#3182CE'; // text-primary equivalent
            break;
        case 'services':
            $w('#servicesLink').style.color = '#3182CE';
            break;
        case 'why-choose-us':
            $w('#whyChooseUsLink').style.color = '#3182CE';
            break;
        case 'testimonials':
            $w('#testimonialsLink').style.color = '#3182CE';
            break;
        case 'events':
            $w('#eventsLink').style.color = '#3182CE';
            break;
        case 'contact':
            $w('#contactLink').style.color = '#3182CE';
            break;
    }
}

// Function to set up navigation link click handlers
function setupNavigationLinks() {
    // Header navigation
    $w('#homeLink').onClick(() => wixLocation.to('/'));
    $w('#servicesLink').onClick(() => wixLocation.to('/services'));
    $w('#whyChooseUsLink').onClick(() => wixLocation.to('/why-choose-us'));
    $w('#testimonialsLink').onClick(() => wixLocation.to('/testimonials'));
    $w('#eventsLink').onClick(() => wixLocation.to('/events'));
    $w('#contactLink').onClick(() => wixLocation.to('/contact'));
    
    // Footer quick links
    $w('#footerHomeLink').onClick(() => wixLocation.to('/'));
    $w('#footerServicesLink').onClick(() => wixLocation.to('/services'));
    $w('#footerWhyChooseUsLink').onClick(() => wixLocation.to('/why-choose-us'));
    $w('#footerTestimonialsLink').onClick(() => wixLocation.to('/testimonials'));
    $w('#footerEventsLink').onClick(() => wixLocation.to('/events'));
    $w('#footerContactLink').onClick(() => wixLocation.to('/contact'));
    $w('#footerBookNowLink').onClick(() => wixLocation.to('/booking'));
}
